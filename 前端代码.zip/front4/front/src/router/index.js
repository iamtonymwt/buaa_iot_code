import Vue from 'vue'
import Router from 'vue-router'
import temperature from '../views/temperature/index.vue'
import background from '../components/background'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [{
    path: '/',
    name: 'background',
    component: background
  }, {
    path: '/temperature',
    name: 'temperature',
    component: temperature
  }
  ]
})
