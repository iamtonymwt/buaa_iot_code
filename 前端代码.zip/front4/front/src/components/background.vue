<template>
  <div class="background">
    <img src="../assets/pic.png" alt="背景图"/>
    <Main></Main>
  </div>
</template>
<script>
import Main from './Main'

export default {
  name: 'background',
  data () {
    return {
    }
  },
  components: {
    Main
  }
}
</script>
<style scoped>
.background img {
  height: 1000px;
  width: 100%;
  background-size: auto;
  opacity: 0.95;
  filter: alpha(opacity=60);
}
</style>
