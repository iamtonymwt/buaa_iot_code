<template>

  <div class="main">
    <el-row :gutter="10" type="flex" class="row-bg" justify="center">
      <el-col :span="8">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><i class="el-icon-alarm-clock"></i> 电机控制</span>
          </div>
          <div>
            <el-button class="button-wrap" v-on:click="motor_on" type="warning">启动电机</el-button>
            <el-button class="button-wrap" v-on:click="motor_off" type="success">关闭电机</el-button>
          </div>
          <div style="height: 140px"></div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><i class="el-icon-sunrise-1"></i> LED控制</span>
          </div>
          <div>
            <el-button class="button-wrap" v-on:click="led_on" type="warning">启动LED</el-button>
            <el-button class="button-wrap" v-on:click="led_off" type="success">关闭LED</el-button>
          </div>
          <div style="height: 140px"></div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><i class="el-icon-bell"></i> 警报控制</span>
          </div>
          <div>
            <el-button class="button-wrap" v-on:click="alarm_on" type="warning">启动报警</el-button>
            <el-button class="button-wrap" v-on:click="alarm_off" type="success">解除报警</el-button>
          </div>
          <div style="height: 140px"></div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="10" type="flex" class="row-bg" justify="center">
      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><i class="el-icon-light-rain"></i> 温湿度管理</span>
          </div>
          <div>
            <el-row>
              <el-button class="button-wrap" v-on:click="report_on" type="primary">开始上报温湿度</el-button>
              <el-button class="button-wrap" v-on:click="report_off" type="info">停止上报温湿度</el-button>
            </el-row>
            <el-row>
              <el-button class="button-wrap" v-on:click="show_new_data" type="success">获取最新温湿度</el-button>
              <el-button class="button-wrap" v-on:click="show_data" type="warning">历史温度曲线</el-button>
            </el-row>
          </div>
          <div style="height: 100px"></div>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span><i class="el-icon-goblet-square-full"></i> 设置阈值</span>
          </div>
          <el-form
            ref="loginFormRef"
            :model="thresholdForm"
            :rules="thresholdFormRules"
            label-width="80px"
            class="threshold_form"
            align="top"
          >
            <el-form-item label="humidity" prop="humidity">
              <el-input v-model="thresholdForm.humidity_data" prefix-icon="iconfont icon-user"></el-input>
            </el-form-item>
            <el-form-item label="temperature" prop="temperature">
              <el-input v-model="thresholdForm.temperature_data" prefix-icon="iconfont icon-user"></el-input>
            </el-form-item>
          </el-form>
          <el-button class="button-wrap" v-on:click="threshold_set" type="success">设置阈值</el-button>
          <div style="height: 56px"></div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import axios from 'axios'
axios.defaults.baseURL = '/api'

export default {
  name: 'Main',
  data () {
    return {
      startAlarmData: {
        control_int: 1
      },
      stopAlarmData: {
        control_int: 0
      },
      thresholdForm: {
        humidity_data: '',
        temperature_data: ''
      },
      // 表单验证
      thresholdFormRules: {
        threshold: [
          {required: true, message: 'Please type in a threshold', trigger: 'blur'}
        ]
      }
    }
  },
  methods: {
    motor_on () {
      console.log('Start motor!')
      axios.get('motor_control', {
        params: {
          control_int: 1
        }
      }).then(response => {

      })
    },
    motor_off () {
      console.log('Stop motor!')
      axios.get('motor_control', {
        params: {
          control_int: 0
        }
      }).then(response => {
      })
    },
    led_on () {
      console.log('Turn up led!')
      axios.get('led_control', {
        params: {
          control_int: 1
        }
      }).then(response => {
      })
    },
    led_off () {
      console.log('Turn down led!')
      axios.get('led_control', {
        params: {
          control_int: 0
        }
      }).then(response => {
      })
    },
    alarm_on () {
      console.log('Start Alarm!')
      axios.get('alarm_control', {
        params: {
          control_int: 1
        }
      }).then(response => {
      })
    },
    alarm_off () {
      console.log('Stop Alarm!')
      axios.get('alarm_control', {
        params: {
          control_int: 0
        }
      }).then(response => {
      })
    },
    report_on () {
      console.log('Start reporting temperature and humidity data.')
      axios.get('report_control', {
        params: {
          control_int: 1
        }
      }).then(response => {
      })
    },
    report_off () {
      console.log('Stop reporting temperature and humidity data.')
      axios.get('report_control', {
        params: {
          control_int: 0
        }
      }).then(response => {
      })
    },
    threshold_set () {
      console.log('Set a threshold.')
      axios.get('threshold_set', {
        params: {
          humidity_data: parseInt(this.thresholdForm.humidity_data),
          temperature_data: parseInt(this.thresholdForm.temperature_data)
        }
      }).then(response => {
      })
    },
    show_new_data () {
      const that = this
      that.$axios.get('show_new_data', {}).then(function (response) {
        console.log('1:receive new temperature and humidity data!')
        console.log(response.data)
        that.$notify({
          title: 'Notice',
          message: '当前温度: ' + response.data.temperature_data + '℉<br>当前湿度: ' + response.data.humidity_data + '%',
          dangerouslyUseHTMLString: true,
          duration: 0,
          position: 'bottom-left',
          type: 'success'
        })
      })
      // console.log('2:receive new temperature and humidity data!')
      // that.$notify({
      //   title: 'Notice',
      //   message: '当前温度:' + '<br>当前湿度:',
      //   dangerouslyUseHTMLString: true,
      //   duration: 0,
      //   position: 'bottom-left',
      //   type: 'success'
      // })
    },
    show_data () {
      axios.get('show_data', {}).then(response => {
      })
      this.$router.push('temperature')
    },
    test () {
      axios.get('TEST', {}).then(response => {
      })
    }
  }
}

</script>

<style scoped>
.main {
  /* background-color: brown; */
  width: 90%;
  height: 100%;

  position: fixed;
  top: 10%;
  bottom: 10%;
  /* right:10rem; */
  left: 80px;
  right: 80px;
  border-style: solid;
  border-radius: 0.5rem;
  border-color: white;
  border-width: 0.1rem;
}

.el-col {
  border-radius: 4px;
}

.bg-purple-dark {
  background: #99a9bf;
}

.bg-purple {
  background: #d3dce6;
}

.bg-purple-light {
  background: #e5e9f2;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
}

.row-bg {
  padding: 10px 0;
  background-color: #f9fafc;
}

.Main-wrap {
  position: absolute;
  height: 100%;
  width: 100%;
  top: 0%;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 16px;
  /* background-color: #fff; */
}

.button-wrap {
  margin-top: 20px;
  height: 60px;
  width: 150px;
  justify-content: center;
  align-items: center;
  font-size: 14px;
}

.threshold_form {
  position: relative;
  top: 20px;
  bottom: 5px;
  width: 80%;
  padding: 0 20px;
  box-sizing: border-box;
  font-size: 16px;
  justify-content: center;
  align-items: center;
  color: #b3d8ff;
}

.label-wrap {
  width: 40px;
  font-size: 30px;
  color: #d9ecff;
}

.el-header {
  background-color: #B3C0D1;
  color: #333;
  line-height: 60px;
}

.el-aside {
  color: #333;
}
</style>
