<template>
  <div class="wrap">
    <div id="main"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts'

export default {
  name: '',
  data () {
    return {
      msg: ''
    }
  },
  mounted () {
    this.get()
    this.getchart()
  },
  methods: {
    // 获取数据
    getchart () {
      const that = this
      that.$axios.get('show_data', {}).then(function (response) {
        console.log('1:receive the history of temperature and humidity data!')
        console.log(response.data)
      })
    },

    get () {
      // 基于准备好的dom，初始化echarts实例
      var myChart = echarts.init(document.getElementById('main'))

      this.$axios.get('show_data', {}).then(function (response) {
        console.log('1:receive the history of temperature and humidity data!')
        console.log(response.data)

        var timeArray = []
        var temperatureArray = []
        var humidityArray = []
        for (let i = 0; i < response.data.length; i++) {
          timeArray.push(response.data[i].time)
          temperatureArray.push(response.data[i].temperature_data)
          humidityArray.push(response.data[i].humidity_data)
        }
        // 使用刚指定的配置项和数据显示图表。
        var option = {
          title: {
            left: 'left',
            text: '温湿度折线统计图'
          },
          dataZoom: [
            {
              type: 'slider', // 滑动轴
              start: 1, // 距离左侧0刻度的距离，1%
              end: 35 // 距离左侧 0刻度的距离，35%，相当于规定了滑动的范围
            }
          ],
          xAxis: {
            type: 'category',
            name: '时间',
            data: timeArray
          },
          // yAxis: {
          //   name: '温度 ℃ / 湿度 %RH',
          //   type: 'value'
          //   // axisLabel: {
          //   //   formatter: "{value} °C",
          //   // },
          // },
          yAxis: [
            {
              name: '温度 ℉ / 湿度 %RH',
              type: 'value',
              min: 20,
              max: 100
            }
            // {
            //   name: '湿度 %RH',
            //   min: 20,
            //   max: 40,
            //   type: 'value',
            //   position: 'right'
            // }
          ],
          legend: {
            data: ['湿度', '温度']
          },
          series: [
            {
              name: '湿度',
              stack: 'Total',
              data: humidityArray,
              type: 'line',
              smooth: true
            },
            {
              name: '温度',
              stack: 'Total',
              data: temperatureArray,
              type: 'line',
              smooth: true
            }
          ]
        }
        myChart.setOption(option)
      })
    }
  }
}
</script>

<style scoped>
.wrap {
  position: relative;
}

#main {
  width: 70%;
  height: 700px;
  margin: 0 auto;
  padding-top: 130px;
}
</style>
